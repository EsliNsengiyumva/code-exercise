package onlineShop.dao;

import java.util.List;

import onlineShop.model.CartInfo;
import onlineShop.model.OrderDetailInfo;
import onlineShop.model.OrderInfo;
import onlineShop.model.PaginationResult;

public interface OrderDAO {

	public void saveOrder(CartInfo cartInfo);

	public PaginationResult<OrderInfo> listOrderInfo(int page, int maxResult, int maxNavigationPage);

	public OrderInfo getOrderInfo(String orderId);

	public List<OrderDetailInfo> listOrderDetailInfos(String orderId);

}
