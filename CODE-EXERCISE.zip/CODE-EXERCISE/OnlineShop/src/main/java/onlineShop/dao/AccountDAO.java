package onlineShop.dao;

import onlineShop.entity.Account;

public interface AccountDAO {
     
    public Account findAccount(String userName );
    

}
